# Sobriety

## What Is Sobriety?

Sobriety is a simple and minimal app to track how long you've been sober from anything you want. It'll tell you how long it's been since you logged a relapse, and the average time between your three most recent relapses, so that you have more input with which to work on recovery. Sobriety has no trackers, and runs completely on your device, and every feature is completely free.

[<img src="https://fdroid.gitlab.io/artwork/badge/get-it-on.png"
     alt="Get it on F-Droid"
     height="80">](https://f-droid.org/packages/com.katiearose.sobriety/)

or get the APK from the [Releases section](https://github.com/KiARC/Sobriety/releases/latest).

## Sobriety's Story

I mostly designed this out of spite for I Am Sober, which monetizes addiction recovery. This started as something I just wrote in the time I had between classes for a friend who was struggling with addiction and couldn't get an I Am Sober subscription to track all the things he was struggling with, and I really just decided to publish it because I didn't see a reason not to, but then it got picked up by the IzzyOnDroid repository and I decided it was genuinely going to be worth working on further if people were actually aware of it. Since then a lot of tweaks have been made and the amazing *JakeGonder* has helped out quite a bit, and I am honestly super proud of how far this has come. Recently (as of writing this),  Donnnno, the creator of [the impressive Arcticons icon pack](https://github.com/Donnnno/Arcticons) has added a Sobriety icon, and I am over the moon with pride for the recognition. I hope Sobriety is able to help more people, and I will continue to work on it when I'm able to because I want to see it grow.

Since writing this, the incredible *cubandle* and *unbiaseduser* have contributed quite a lot, and I'm really grateful for that.

### About I Am Sober

I'm only half joking when I say I hate I Am Sober. [It has several trackers and requires far more permissions than is reasonable for the features it provides](https://reports.exodus-privacy.eu.org/en/reports/com.thehungrywasp.iamsober/latest/), and the fact that a subscription is required to track more than two individual addictions is just horrific to me. Displaying the time since a given date, and allowing that date to be reset to the current time, are such simple features to implement that I genuinely cannot fathom how they can in good conscience monetize them, especially when their target audience is *people struggling with addiction*. I just find the whole concept somewhat upsetting. For that reason, Sobriety will never have any trackers or anything of the sort, and will always be completely free. I want to help people, not profit off of their struggles.

## Developer Contact Info
- Here on GitHub, via Issues, Discussions, etc
- My personal email address (katiearose@pm.me)

Feel free to contact me about any issues, suggestions or comments you have about Sobriety!

# Repository Metadata (via Shields.io)
## Core
[![License](https://img.shields.io/github/license/KiARC/Sobriety?style=for-the-badge&color=success)](https://www.gnu.org/licenses/gpl-3.0.html)
[![GitHub Workflow Status](https://img.shields.io/github/actions/workflow/status/KiARC/Sobriety/ci.yml?branch=master&style=for-the-badge)](https://github.com/KiARC/Sobriety/actions/workflows/ci.yml?query=branch%3Amaster)
[![Maintenance](https://img.shields.io/maintenance/yes/2023?style=for-the-badge)](https://github.com/KiARC/Sobriety)
## Size
[![GitHub code size](https://img.shields.io/github/languages/code-size/KiARC/Sobriety?style=for-the-badge)](https://github.com/KiARC/Sobriety)
[![GitHub repo size](https://img.shields.io/github/repo-size/KiARC/Sobriety?style=for-the-badge)](https://github.com/KiARC/Sobriety)
## Release Info
[![GitHub all releases](https://img.shields.io/github/downloads/KiARC/Sobriety/total?style=for-the-badge&label=Downloads%20%28All%20Releases%29?)](https://github.com/KiARC/Sobriety/releases)
[![GitHub downloads by release (latest by date)](https://img.shields.io/github/downloads/KiARC/Sobriety/latest/total?style=for-the-badge&label=Downloads%20%28Latest%20Release%29?)](https://github.com/KiARC/Sobriety/releases/latest)

[![GitHub release (latest SemVer)](https://img.shields.io/github/v/release/KiARC/Sobriety?label=Latest%20Release&sort=semver&style=for-the-badge)](https://github.com/KiARC/Sobriety/releases/latest)
[![GitHub Release Date](https://img.shields.io/github/release-date/KiARC/Sobriety?label=Latest%20Release%20Date&style=for-the-badge&sort=semver)](https://github.com/KiARC/Sobriety/releases/latest)
[![F-Droid](https://img.shields.io/f-droid/v/com.katiearose.sobriety?style=for-the-badge)](https://f-droid.org/en/packages/com.katiearose.sobriety/)
## Issue Counts
[![GitHub open issues](https://img.shields.io/github/issues-raw/KiARC/Sobriety?style=for-the-badge)](https://github.com/KiARC/Sobriety/issues)
[![GitHub closed issues](https://img.shields.io/github/issues-closed-raw/KiARC/Sobriety?style=for-the-badge)](https://github.com/KiARC/Sobriety/issues?q=is%3Aissue+is%3Aclosed)
## PR Counts
[![GitHub open pull requests](https://img.shields.io/github/issues-pr-raw/KiARC/Sobriety?style=for-the-badge)](https://github.com/KiARC/Sobriety/pulls)
[![GitHub closed pull requests](https://img.shields.io/github/issues-pr-closed-raw/KiARC/Sobriety?style=for-the-badge)](https://github.com/KiARC/Sobriety/pulls?q=is%3Apr+is%3Aclosed)
## Stats
[![GitHub commit activity](https://img.shields.io/github/commit-activity/w/KiARC/Sobriety?style=for-the-badge)](https://github.com/KiARC/Sobriety/graphs/commit-activity)
[![GitHub commits since latest release (by date)](https://img.shields.io/github/commits-since/KiARC/Sobriety/latest?style=for-the-badge)](https://github.com/KiARC/Sobriety/graphs/commit-activity)

[![GitHub contributors](https://img.shields.io/github/contributors/KiARC/Sobriety?style=for-the-badge)](https://github.com/KiARC/Sobriety/graphs/contributors)
[![GitHub Discussions](https://img.shields.io/github/discussions/KiARC/Sobriety?style=for-the-badge)](https://github.com/KiARC/Sobriety/discussions)
