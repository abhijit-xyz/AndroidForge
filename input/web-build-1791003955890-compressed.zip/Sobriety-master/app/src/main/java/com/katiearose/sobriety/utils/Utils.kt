package com.katiearose.sobriety.utils

import android.app.Activity
import android.content.Context
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.AppCompatEditText
import androidx.preference.PreferenceManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.katiearose.sobriety.R
import com.katiearose.sobriety.activities.Main
import com.katiearose.sobriety.shared.CacheHandler
import kotlinx.datetime.DateTimeUnit
import java.time.Duration
import java.time.Instant
import java.time.LocalDateTime
import java.time.Period
import java.util.*

private const val MINUTE = 60
private const val HOUR = MINUTE * 60
private const val DAY = HOUR * 24
private const val WEEK = DAY * 7
private const val YEAR = (DAY * 365.25).toInt()
private const val MONTH = YEAR / 12


fun Context.convertSecondsToString(given: Long): String {
    if (given == -1L) return ""
    var time = given
    val s = time % MINUTE
    time -= s
    val m = (time % HOUR) / MINUTE
    time -= m * MINUTE
    val h = (time % DAY) / HOUR
    time -= h * HOUR
    val d = (time % WEEK) / DAY
    time -= d * DAY
    val w = (time % MONTH) / WEEK
    time -= w * WEEK
    val mo = (time % YEAR) / MONTH
    time -= mo * MONTH
    val y = time / YEAR
    val stringBuilder = StringBuilder()
    if (y != 0L) stringBuilder.append(resources.getQuantityString(R.plurals.years, y.toInt(), y)).append(" ")
    if (mo != 0L) stringBuilder.append(resources.getQuantityString(R.plurals.months, mo.toInt(), mo)).append(" ")
    if (w != 0L) stringBuilder.append(resources.getQuantityString(R.plurals.weeks, w.toInt(), w)).append(" ")
    if (d != 0L) stringBuilder.append(resources.getQuantityString(R.plurals.days, d.toInt(), d)).append(" ")
    if (h != 0L) stringBuilder.append(resources.getQuantityString(R.plurals.hours, h.toInt(), h)).append(" ")
    if (m != 0L) stringBuilder.append(resources.getQuantityString(R.plurals.minutes, m.toInt(), m)).append(" ")
    if (!(y == 0L && mo == 0L && w == 0L && d == 0L && h == 0L && m == 0L)) stringBuilder.append(
        getString(R.string.and)
    ).append(" ")
    stringBuilder.append(resources.getQuantityString(R.plurals.seconds, s.toInt(), s))
    return stringBuilder.toString()
}

/**
 * Elapsed time between two moments, broken down into calendar units.
 *
 * The calendar part (years, months, days) is counted *forward from the start date*, and whatever is
 * left over after that is expressed in hours, minutes and seconds (always less than 24 hours).
 * Counting forward matters: counting backwards from "now" gives different answers around month
 * ends (e.g. a counter that jumps to "1 month 1 day" a day early).
 */
private data class Elapsed(
    val years: Int, val months: Int, val days: Int,
    val hours: Int, val minutes: Int, val seconds: Int,
    val start: LocalDateTime, val end: LocalDateTime
)

private fun calculateElapsed(startMillis: Long, endMillis: Long): Elapsed {
    val zone = TimeZone.getDefault().toZoneId()
    val start = LocalDateTime.ofInstant(Instant.ofEpochMilli(startMillis), zone)
    // Never go negative (e.g. clock changes); treat it as "nothing has elapsed yet"
    val end = LocalDateTime.ofInstant(Instant.ofEpochMilli(endMillis.coerceAtLeast(startMillis)), zone)

    var period = Period.between(start.toLocalDate(), end.toLocalDate())
    var anchor = start.plus(period)
    if (anchor.isAfter(end)) {
        // The last (calendar) day isn't complete yet: its time of day hasn't been reached
        period = Period.between(start.toLocalDate(), end.toLocalDate().minusDays(1))
        anchor = start.plus(period)
    }
    val rest = Duration.between(anchor, end)
    return Elapsed(
        period.years, period.months, period.days,
        rest.toHoursPart(), rest.toMinutesPart(), rest.toSecondsPart(),
        start, end
    )
}

// Expects start and end timestamps in epoch milliseconds
fun Context.convertRangeToString(start: Long, end: Long = Instant.now().toEpochMilli()): String {
    if (start == -1L) return ""
    val elapsed = calculateElapsed(start, end)

    val y = elapsed.years
    val mo = elapsed.months
    val d = elapsed.days % 7
    val w = elapsed.days / 7
    val h = elapsed.hours
    val m = elapsed.minutes
    val s = elapsed.seconds

    val stringBuilder = StringBuilder()
    if (y != 0) stringBuilder.append(resources.getQuantityString(R.plurals.years, y, y)).append(" ")
    if (mo != 0) stringBuilder.append(resources.getQuantityString(R.plurals.months, mo, mo)).append(" ")
    if (w != 0) stringBuilder.append(resources.getQuantityString(R.plurals.weeks, w, w)).append(" ")
    if (d != 0) stringBuilder.append(resources.getQuantityString(R.plurals.days, d, d)).append(" ")
    if (h != 0) stringBuilder.append(resources.getQuantityString(R.plurals.hours, h, h)).append(" ")
    if (m != 0) stringBuilder.append(resources.getQuantityString(R.plurals.minutes, m, m)).append(" ")
    if (!(y == 0 && mo == 0 && w == 0 && d == 0 && h == 0 && m == 0)) stringBuilder.append(
        getString(R.string.and)
    ).append(" ")
    stringBuilder.append(resources.getQuantityString(R.plurals.seconds, s, s))
    return stringBuilder.toString()
}

// Each triple contains the raw number (e.g. 12), the percentage in per mille (500), and the unit (hours)
fun convertRangeToPercentList(start: Long, end: Long = Instant.now().toEpochMilli())
        : List<Triple<Int, Int, DateTimeUnit>> {
    val elapsed = calculateElapsed(start, end)

    // Calculate the number of days until the month period ends
    val nextMonth = elapsed.start.plus(Period.of(elapsed.years, elapsed.months + 1, 0))
    val daysLeft = Duration.between(elapsed.end, nextMonth).toDays().toInt().coerceAtLeast(0)

    // Initially store denominator in second part of triple
    return listOf(
        // Years progress bar should never complete, but crosses 50% at 2 years
        Triple(elapsed.years, elapsed.years + 2, DateTimeUnit.YEAR),
        Triple(elapsed.months, 12, DateTimeUnit.MONTH),
        // Weeks make the visualization non-whole so they are omitted
        Triple(elapsed.days, elapsed.days + daysLeft, DateTimeUnit.DAY),
        Triple(elapsed.hours, 24, DateTimeUnit.HOUR),
        Triple(elapsed.minutes, 60, DateTimeUnit.MINUTE),
        Triple(elapsed.seconds, 60, DateTimeUnit.SECOND)
    ).map {
        Triple(
            it.first,
            (1000 * it.first.toDouble().div(it.second)).toInt(),
            it.third
        )
    }
}

fun Context.showConfirmDialog(title: String, message: String, action: () -> Unit) {
    MaterialAlertDialogBuilder(this)
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton(android.R.string.ok) { _, _ -> action() }
        .setNegativeButton(android.R.string.cancel, null)
        .show()
}

fun Activity.applyThemes() {
    val preferences = PreferenceManager.getDefaultSharedPreferences(this)
    when (preferences.getString("theme", "system")) {
        "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    }
    if (preferences.getBoolean("material_you", false)) {
        setTheme(R.style.Theme_Sobriety_Material3)
    } else setTheme(R.style.Theme_Sobriety)
}

fun Activity.checkValidIntentData() : Int {
    val index = intent.getIntExtra(Main.EXTRA_ADDICTION_POSITION, -1)
    require(index != -1) { "Invalid intent data received" }
    return index
}

fun AppCompatEditText.isInputEmpty(): Boolean = text == null || text.toString().isBlank()

fun View.toggleVisibility() {
    visibility = if (visibility == View.VISIBLE) View.GONE else View.VISIBLE
}

fun Context.toast(@StringRes textRes: Int) = Toast.makeText(this, textRes, Toast.LENGTH_SHORT).show()

inline var TextView.textResource: Int
    set(@StringRes value) = setText(value)
    @Deprecated("This property is set-only, don't bother.", level = DeprecationLevel.HIDDEN)
    get() = error("don't")

fun CacheHandler.write() = writeCache(Main.addictions)