package com.katiearose.sobriety

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.katiearose.sobriety.databinding.ListItemUrgeBinding
import com.katiearose.sobriety.shared.Addiction
import com.katiearose.sobriety.utils.getDateFormatPattern
import com.katiearose.sobriety.utils.getSharedPref
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class UrgeAdapter(
    private val addiction: Addiction,
    private val context: Context,
    private val deleteButtonAction: (Addiction.Urge) -> Unit
) : ListAdapter<Addiction.Urge, UrgeAdapter.UrgeViewHolder>(object : DiffUtil.ItemCallback<Addiction.Urge>() {
    // The time is effectively unique per urge, so it works as an identity
    override fun areItemsTheSame(oldItem: Addiction.Urge, newItem: Addiction.Urge) = oldItem.time == newItem.time
    override fun areContentsTheSame(oldItem: Addiction.Urge, newItem: Addiction.Urge) = oldItem == newItem
}) {
    private val dateFormat =
        DateTimeFormatter.ofPattern("HH:mm ${context.getSharedPref().getDateFormatPattern()}")

    init { update() }

    fun update() = submitList(addiction.getUrgesList())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UrgeViewHolder {
        val binding = ListItemUrgeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UrgeViewHolder(binding) { deleteButtonAction(currentList[it]) }
    }

    override fun onBindViewHolder(holder: UrgeViewHolder, position: Int) {
        val urge = currentList[position]
        holder.time.text = dateFormat.format(Instant.ofEpochMilli(urge.time).atZone(ZoneId.systemDefault()))
        holder.intensity.text = context.getString(R.string.urge_intensity_value, urge.intensity)
        holder.intensity.setTextColor(
            ResourcesCompat.getColor(
                context.resources,
                when {
                    urge.intensity >= 8 -> R.color.red
                    urge.intensity >= 4 -> R.color.orange
                    else -> R.color.green
                },
                context.theme
            )
        )
        holder.note.visibility = if (urge.note.isBlank()) View.GONE else View.VISIBLE
        holder.note.text = urge.note
    }

    class UrgeViewHolder(binding: ListItemUrgeBinding, deleteButtonAction: (Int) -> Unit) : ViewHolder(binding.root) {
        val time = binding.urgeTime
        val intensity = binding.urgeIntensity
        val note = binding.urgeNote

        init {
            binding.btnDelete.setOnClickListener {
                if (adapterPosition != -1) deleteButtonAction(adapterPosition)
            }
        }
    }
}
