package com.katiearose.sobriety.activities

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.katiearose.sobriety.R
import com.katiearose.sobriety.UrgeAdapter
import com.katiearose.sobriety.databinding.ActivityUrgesBinding
import com.katiearose.sobriety.databinding.DialogAddUrgeBinding
import com.katiearose.sobriety.shared.Addiction
import com.katiearose.sobriety.shared.CacheHandler
import com.katiearose.sobriety.utils.applyThemes
import com.katiearose.sobriety.utils.checkValidIntentData
import com.katiearose.sobriety.utils.showConfirmDialog
import com.katiearose.sobriety.utils.toast
import com.katiearose.sobriety.utils.write
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class Urges : AppCompatActivity() {

    private lateinit var binding: ActivityUrgesBinding
    private lateinit var addiction: Addiction
    private lateinit var adapter: UrgeAdapter
    private lateinit var cacheHandler: CacheHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        applyThemes()
        super.onCreate(savedInstanceState)
        binding = ActivityUrgesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        cacheHandler = CacheHandler(this)
        addiction = Main.addictions[checkValidIntentData()]
        title = getString(R.string.urges_title, addiction.name)

        adapter = UrgeAdapter(addiction, this) { urge ->
            val time = DateTimeFormatter.ofPattern("HH:mm dd/MM/uuuu")
                .format(Instant.ofEpochMilli(urge.time).atZone(ZoneId.systemDefault()))
            showConfirmDialog(getString(R.string.delete), getString(R.string.delete_urge_confirm, time)) {
                addiction.urges.remove(urge)
                refresh()
            }
        }
        binding.urgesList.layoutManager = LinearLayoutManager(this)
        binding.urgesList.adapter = adapter
        binding.addUrgeFab.setOnClickListener { showLogUrgeDialog() }
        updateSummary()
    }

    private fun showLogUrgeDialog() {
        val dialogBinding = DialogAddUrgeBinding.inflate(layoutInflater)
        val dialog = BottomSheetDialog(this)
        dialog.setContentView(dialogBinding.root)

        fun showIntensity(value: Int) {
            dialogBinding.intensityLabel.text = getString(R.string.urge_intensity_value, value)
        }
        showIntensity(dialogBinding.intensitySlider.value.toInt())
        dialogBinding.intensitySlider.addOnChangeListener { _, value, _ -> showIntensity(value.toInt()) }

        dialogBinding.btnSaveUrge.setOnClickListener {
            addiction.logUrge(
                dialogBinding.intensitySlider.value.toInt(),
                dialogBinding.urgeNoteInput.text?.toString().orEmpty()
            )
            refresh()
            toast(R.string.urge_logged)
            dialog.dismiss()
        }
        // The keyboard would otherwise cover the Save button on small screens
        dialog.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    private fun refresh() {
        cacheHandler.write()
        adapter.update()
        updateSummary()
    }

    private fun updateSummary() {
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()
        val todayCount = addiction.urges.count {
            Instant.ofEpochMilli(it.time).atZone(zone).toLocalDate() == today
        }
        binding.urgesSummary.text = getString(R.string.urges_summary, addiction.urges.size, todayCount)
        val empty = addiction.urges.isEmpty()
        binding.noUrgesPrompt.visibility = if (empty) View.VISIBLE else View.GONE
        binding.urgesSummary.visibility = if (empty) View.GONE else View.VISIBLE
    }
}
